import java.util.Objects;

public class ImmutableBook {
    public final String title;
    public final String author;
    public final String isbn;
    public ImmutableBook(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getIsbn() {
        return isbn;
    }
    @Override
    public String toString() {
        return "title=" + title + ", author=" + author + ", isbn=" + isbn + "";
    }
    @Override
    public boolean equals(Object obj) {
        return (this == obj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, author, isbn);
    }
}
