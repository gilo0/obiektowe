public record BankAccount(long numerKonta, double saldo) {
    public BankAccount(long numerKonta, double saldo) {
        this.numerKonta = numerKonta;
        this.saldo = 0;
    }
}
