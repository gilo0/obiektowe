public record Person(String firstName, String lastName, Address address, int age) {
    public Person(String firstName, String lastName, Address address, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        if(age < 0){
            this.age = 0;
        }
        else {
            this.age = age;
        }
    }
}
