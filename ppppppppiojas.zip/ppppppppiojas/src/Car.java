public record Car(String brand, String model, double FuelConsumption) {
    public double FuelCost(double fuelPrice, double distance){
        return (fuelPrice * distance)/FuelConsumption;
    }
}
