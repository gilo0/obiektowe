public class Electronics {

    public final void turnOn(){
        System.out.println("urzadzenie wlaczone");
    }
}
