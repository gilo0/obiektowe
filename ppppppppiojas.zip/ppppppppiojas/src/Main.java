
public class Main {
    public static void main(String[] args) {

//        BookDTO book1 = new BookDTO("hobit", "tolkien", 1.99,2023);
//        BookDTO book2 = new BookDTO("armenian psycho", "john arnold", 50.99, 2003);
//        System.out.println(book1);
//        System.out.println(book2);
//        Address adres = new Address("anglity", "4", "14-400", "paslek");
//        Person erczyk = new Person("erczyk", "czernik", adres, -5);
//        System.out.println(erczyk);
//        Car maluh = new Car("fiat", "maly", 1.01);
//        System.out.println(maluh.FuelCost(5.46, 100));

        double[] ratings = {5.3, 7.1, 9.9};
        MusicAlbum peanits = new MusicAlbum("peanits", "wezer", ratings);
        peanits.displayRating();
        peanits.addRating(9.5);
        peanits.displayRating();
        RockAlbum peper = new RockAlbum("chili peper", "red hot", ratings, "super turbo dark death metal");
        System.out.println(peper.title + peper.rockGenre);
        System.out.println(peper.toString());
        System.out.println(peper.hashCode());
    }
}