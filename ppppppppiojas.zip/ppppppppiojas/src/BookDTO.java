public record BookDTO(String title, String author, double price, int yearOfPublication)  {
}
