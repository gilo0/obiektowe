import java.util.Objects;

public class RockAlbum extends MusicAlbum{
    String rockGenre;

    public RockAlbum(String title, String author, double[] ratings, String rockGenre) {
        this.title = title;
        this.artist = author;
        this.ratings = ratings;
        this.rockGenre = rockGenre;
    }

    public void addRating(double rating){
        double[] newRatings = new double[ratings.length + 1];
        for(int i = 0; i < ratings.length; i++){
            newRatings[i] = ratings[i];
        }
        newRatings[ratings.length] = rating;
        ratings = newRatings;
    }

    public void clearRatings(){
        this.ratings = null;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public double[] getRatings() {
        return ratings;
    }

    public void setRatings(double[] ratings) {
        this.ratings = ratings;
    }

    @Override
    public String toString() {
        return "title: "+title+" artist: "+artist+" ratings: "+ratings+"";
    }

    @Override
    public boolean equals(Object obj) {
        return (this == obj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, artist, ratings);
    }
}
