public class KlientFirmowy extends Klient{
    private final String NIP;
    private final String REGON;

    public KlientFirmowy(String NIP, String REGON){
        this.NIP = NIP;
        this.REGON = REGON;
    }
}
