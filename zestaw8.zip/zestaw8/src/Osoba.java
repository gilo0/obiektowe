public class Osoba{
    private String imie;
    private String nazwisko;
}
