public abstract class Owoc {
    private String nazwa;

    public Owoc(String nazwa) {
        this.nazwa = nazwa;
    }

    public abstract void smak();
    public abstract void Umyj();
    public abstract void zjedz();
}
