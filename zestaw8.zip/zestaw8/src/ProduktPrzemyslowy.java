public class ProduktPrzemyslowy extends Produkt{
}
