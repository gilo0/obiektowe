class Adres {
    private String ulica;
    private String numerDomu;
    private String numerMieszkania;
    private String miasto;
    private String kodPocztowy;

    public Adres(String ulica, String numerDomu, String numerMieszkania, String miasto, String kodPocztowy) {
        this.ulica = ulica;
        this.numerDomu = numerDomu;
        this.numerMieszkania = numerMieszkania;
        this.miasto = miasto;
        this.kodPocztowy = kodPocztowy;
    }

    public Adres(String ulica, String numerDomu, String miasto, String kodPocztowy) {
        this.ulica = ulica;
        this.numerDomu = numerDomu;
        this.miasto = miasto;
        this.kodPocztowy = kodPocztowy;
    }

    public void pokaz(){
        System.out.println(kodPocztowy + " " + miasto);
        System.out.println(ulica + " " + numerDomu + " " + (numerMieszkania != null ? "/" + numerMieszkania : ""));
    }

    public static boolean przed(Adres adres1, Adres adres2){
        if(Integer.valueOf(adres1.kodPocztowy)<Integer.valueOf(adres2.kodPocztowy)){
            return true;
        }
        return false;
    }

    public String getClasss() {return "Cześć jestem klasą" + this.getClass().getSimpleName();}


}
