public class KlientIndywidualny  extends Klient{
    private final String PESEL;

    public KlientIndywidualny(String PESEL){
        this.PESEL = PESEL;
    }
}
