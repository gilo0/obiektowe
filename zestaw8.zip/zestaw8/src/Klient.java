import java.util.ArrayList;


public class Klient extends Osoba{
    private String imie;
    private String nazwisko;
    private String adres;
    private ArrayList<Zamowienie> listaZamowien;

    public Klient(String imie, String nazwisko, String adres) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.listaZamowien = new ArrayList<>();
        this.adres = adres;
    }

    public Klient(){}


    public void dodajZamowienie(Zamowienie zamowienie){
        listaZamowien.add(zamowienie);
    }

    public void wyswietlHistorieZamowien(){
        if(listaZamowien.isEmpty()){
            System.out.println("Brak zamowien w historii klienta.");
        }else{
            System.out.println("Historia zamówień klienta " + imie + " " + nazwisko + ":");
            for(Zamowienie zamowienie: listaZamowien){
                zamowienie.wyswietlZamowienie();
                System.out.println();
            }
        }
    }

    ///public static boolean equals(Klient klient1, Klient klient2){
       /// if(klient1.imie == klient2.imie && klient1.nazwisko == klient2.nazwisko){}
    ///}

    public double ObliczLacznyKosztZamowien(){
        double suma = 0.0;
        for(Zamowienie zamowienie: listaZamowien){
            suma += zamowienie.koszyk.obliczCalkowitaWartosc();
        }
        return suma;
    }



}
interface KlientInterface {
    public void dodajZamowienie();

    public void wyswietlHistorieZamowien();

    public double ObliczLacznyKosztZamowien();

    default void kamil(){
        System.out.println("steinbach");
    }
}
