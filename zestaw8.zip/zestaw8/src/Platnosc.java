public class Platnosc {
    private double kwota;
    private String statusPlatnosci;

    public Platnosc(double kwota){
        this.kwota = 0;
        this.statusPlatnosci = "Nieopłacone";
    }

    public static boolean equals(Platnosc platnosc1, Platnosc platnosc2){
        if(platnosc1.kwota == platnosc2.kwota && platnosc1.statusPlatnosci == platnosc2.statusPlatnosci){
            return true;
        }
        return false;
    }

    public void zaplac(){
        this.statusPlatnosci = "Opłacone";
    }

    public String getStatusPlatnosci(){
        return this.statusPlatnosci;
    }

    public double getKwota(){
        return this.kwota;
    }

    public void ustawKwote(double kwota){
        this.kwota = kwota;
    }
}
