public abstract class Warzywo {
    private String nazwa;

    public Warzywo(String nazwa) {
        this.nazwa = nazwa;
    }

    public abstract void smak();
    public abstract void Umyj();
    public abstract void zjedz();
}
