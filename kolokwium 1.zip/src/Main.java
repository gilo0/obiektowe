public class Main {

    public static boolean dokladnosc(double x, double y, int k){
        double wynik = x - y;
        if(wynik <= Math.pow(10, -k)){
            return true;
        }
        return false;
    }

    public static int najblizszySasiad(int S){
        float sqrt = (float) (S / 5 + S / (S / 5)) /2;
        return (int)sqrt;
    }

    public static double pierwiastek(int S, int n, int k){
        double aryt = 0;
        int temp = n-1;
        for(int i = 0; i < n-1; i++){
            aryt += S/5;
        }
        aryt += S/((S/5))^2;
        double sqrt = aryt / temp;
        return sqrt;
    }

    public static int podciag(int[] tab){
        int temp = 1;
        int temp2 = 0;
        try {
            for(int g = 0; g < tab.length; g++) {
                if (tab[g] > tab[g + 1]) {
                    temp++;
                }
                if (temp > temp2) {
                    temp2 = temp;
                }
                if(tab[g] < tab[g + 1]) {
                    temp = 1;
                }
            }
        }
        catch (Exception e) {
        }
        return temp2;
    }

    public static int podciag(int[] tab, int r){
        int temp = 1;
        int temp2 = 0;
        try {
            for(int g = 0; g < tab.length; g++) {
                if (tab[g+1] == (tab[g] - r)) {
                    temp++;
                }
                if (temp > temp2) {
                    temp2 = temp;
                }
                if(tab[g+1] != (tab[g] - r)) {
                    temp = 1;
                }
            }
        }
        catch (Exception e) {
        }
        return temp2;
    }

//    public static boolean czyPalindrom(int n){
//        int dlugosc = 0;
//        int p = n;
//        while(p > 0) {
//            dlugosc++;
//            p = p / 10;
//            return true;
//        }
//    }

    public static void main(String[] args) {
        int[] tab = {5, 2, 1, 10, 9, 8, 7, 6};
        int[] tab2 = {2, 0, 10, 8, 6};
        System.out.println(podciag(tab));
        System.out.println(podciag(tab2, 2));
        System.out.println(najblizszySasiad(20));
        System.out.println(pierwiastek(8, 3, 1));
    }
}