import java.util.ArrayList;

public class Fabryka {
    ArrayList<Elf> listaElfow;
    double dlGeo;
    double szGeo;

    public Fabryka(ArrayList<Elf> listaElfow, double dlGeo, double szGeo) {
        if(listaElfow != null && listaElfow.size() > 0) {
            this.listaElfow = listaElfow;
        }
        if(dlGeo <= 180 && dlGeo >= -180){
            this.dlGeo = dlGeo;
        }
        if(szGeo <= 90 && szGeo >= -90){
            this.szGeo = szGeo;
        }
    }

    public void dodajPracownika(Elf elf){
        listaElfow.add(elf);
    }

    public void usunPracownika(){
        listaElfow.remove(listaElfow.size()-1);
    }

    public Elf najstarszyPracownik(){
        int temp = 0;
        int temp2 = 0;
        for(int i = 0; i < listaElfow.size(); i++){
            if(listaElfow.get(i).wiek > temp2){
                temp2 = listaElfow.get(i).wiek;
                temp = i;
            }
        }
        return listaElfow.get(temp);
    }

    public ArrayList<Elf> getListaElfow() {
        return listaElfow;
    }

    public double getDlGeo() {
        return dlGeo;
    }

    public double getSzGeo() {
        return szGeo;
    }

    public void setListaElfow(ArrayList<Elf> listaElfow) {
        if(listaElfow != null && listaElfow.size() > 0) {
            this.listaElfow = listaElfow;
        }
    }

    public void setDlGeo(double dlGeo) {
        if(dlGeo <= 180 && dlGeo >= -180){
            this.dlGeo = dlGeo;
        }
    }

    public void setSzGeo(double szGeo) {
        if(szGeo <= 90 && szGeo >= -90){
            this.szGeo = szGeo;
        }
    }

    @Override
    public String toString() {
        return "[Fabryka] lista elfow: " + listaElfow + ", szerokosc geograficzna: " + szGeo + ", dlugosc geograficzna: " + dlGeo;
    }

    @Override
    public boolean equals(Object obj){
        if(obj instanceof Fabryka){
            Fabryka other = (Fabryka) obj;
            return other.listaElfow == listaElfow && other.dlGeo == dlGeo && other.szGeo == szGeo;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return listaElfow.hashCode() + (int)dlGeo + (int)szGeo;
    }
}
