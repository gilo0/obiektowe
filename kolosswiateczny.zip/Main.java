import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Elf dzekson = new Elf("dzekson", 15, "worek do bicia");
        Elf dzekson2 = new Elf("dzekson", 15, "worek do bicia");
        Elf arnold = new Elf("arnold", 21, "profesjonalny alkoholik");
        Elf kamil = new Elf("steinbach", 22, "celebryta");
        ArrayList<Elf> elfy = new ArrayList<>();
        elfy.add(arnold);
        elfy.add(dzekson);
        dzekson.przedstawSie();

        Fabryka fabryka = new Fabryka(elfy, 5.6, 6.25);
        System.out.println(fabryka.najstarszyPracownik().imie);
        fabryka.dodajPracownika(kamil);
        System.out.println(fabryka.najstarszyPracownik().imie);

        Renifer karl = new Renifer("karl", 1);
        Renifer karl2 = new Renifer("karl", 1);
        Renifer gurdis = new Renifer("gurdis", 500);
        Renifer boblinson = new Renifer("McBoblinson", 250);
        System.out.println(karl.predkosc);
        karl.nakarmRenifera();
        System.out.println(karl.predkosc);
        ArrayList<Renifer> renifery = new ArrayList<>();
        renifery.add(karl);
        renifery.add(gurdis);
        Sanie sanie = new Sanie(renifery);
        sanie.dodajRenifera(boblinson);
        System.out.println(sanie.najwolniejszyRenifer().imie);
        fabryka.usunPracownika();
        System.out.println(fabryka.toString());
        fabryka.usunPracownika();
        System.out.println(fabryka.toString());
        System.out.println(dzekson.equals(dzekson2));
        System.out.println(sanie.sumaPredkosci());
    }
}