import java.util.ArrayList;

public class Sanie {
    ArrayList<Renifer> renifery;

    public Sanie(ArrayList<Renifer> renifery) {
        if(renifery != null && renifery.size() > 0) {
            this.renifery = renifery;
        }
    }

    public void dodajRenifera(Renifer renifer) {
        renifery.add(renifer);
    }

    public int sumaPredkosci(){
        int suma = 0;
        for(int i = 0; i < renifery.size(); i++){
            suma += renifery.get(i).predkosc;
        }
        return suma;
    }

    public Renifer najwolniejszyRenifer(){
        int temp = 0;
        int temp2 = 0;
        for(int i = 0; i < renifery.size(); i++){
            if(renifery.get(i).predkosc < temp2){
                temp2 = renifery.get(i).predkosc;
                temp = i;
            }
        }
        return renifery.get(temp);
    }

    public ArrayList<Renifer> getRenifery() {
        return renifery;
    }

    public void setRenifery(ArrayList<Renifer> renifery) {
        if(renifery != null && renifery.size() > 0) {
            this.renifery = renifery;
        }
    }

    @Override
    public String toString() {
        return "[Sanie] lista reniferow: " + renifery;
    }

    @Override
    public int hashCode() {
        return renifery.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Sanie) {
            Sanie sanie = (Sanie) obj;
            return renifery.equals(sanie.renifery);
        }
        return false;
    }
}
