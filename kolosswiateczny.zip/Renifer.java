public class Renifer {
    String imie;
    int predkosc;

    public Renifer(String imie, int predkosc) {
        if (imie != null && imie != "") {
            this.imie = imie;
        }
        if(predkosc >= 0){
            this.predkosc = predkosc;
        }
    }

    public void nakarmRenifera(){
        this.predkosc = this.predkosc + 5;
    }

    public String getImie(){
        return imie;
    }

    public int getPredkosc(){
        return predkosc;
    }

    public void setImie(String imie){
        if (imie != null && imie != "") {
            this.imie = imie;
        }
    }

    public void setPredkosc(int predkosc){
        if(predkosc >= 0){
            this.predkosc = predkosc;
        }
    }

    @Override
    public String toString() {
        return "[Renifer] imie: " + imie + ", predkosc: " + predkosc;
    }

    @Override
    public int hashCode() {
        return imie.hashCode() + predkosc;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Renifer) {
            Renifer other = (Renifer) obj;
            return other.imie == imie && other.predkosc == predkosc;
        }
        return false;
    }


}
