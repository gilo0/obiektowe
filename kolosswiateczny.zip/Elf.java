public class Elf {
    String imie;
    int wiek;
    String stanowisko;

    public Elf(String imie, int wiek, String stanowisko) {
        if(imie != null && imie != "") {
            this.imie = imie;
        }
        if(wiek > 0) {
            this.wiek = wiek;
        }
        if(stanowisko != null && stanowisko != "") {
            this.stanowisko = stanowisko;
        }
    }

    public void przedstawSie(){
        System.out.println("Cześć, nazywam sie " + imie + ", mam " + wiek + " lat, a moje stanowisko pracy to " + stanowisko + ".");
    }

    public String getImie(){
        return imie;
    }

    public int getWiek(){
        return wiek;
    }

    public String getStanowisko(){
        return stanowisko;
    }

    public void setImie(String imie){
        if(imie != null && imie != "") {
            this.imie = imie;
        }
    }

    public void setWiek(int wiek){
        if(wiek > 0) {
            this.wiek = wiek;
        }
    }

    public void setStanowisko(String stanowisko){
        if(stanowisko != null && stanowisko != "") {
            this.stanowisko = stanowisko;
        }
    }

    @Override
    public String toString() {
        return "[Elf] imie: " + imie + ", wiek: " + wiek + ", stanowisko: " + stanowisko;
    }

    @Override
    public int hashCode() {
        return imie.hashCode() + wiek + stanowisko.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Elf){
            Elf other = (Elf) obj;
            return other.imie == imie && other.wiek == wiek && other.stanowisko.equals(stanowisko);
        }
        return false;
    }
}
